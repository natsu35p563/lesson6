class BooksController < ApplicationController
  def index
   @books = Book.all# 一覧表示用
   @book = Book.new# 投稿用（form_with用）
  end

  def show
    @book = Book.find(params[:id])
  end

  def new
    @book = Book.new
  end

  def create
    @book = Book.new(book_params)
    if @book.save
      # 成功したとき
      redirect_to @book, notice: 'Book was successfully created.'
    else
      # 失敗したとき
      @books = Book.all
      render :index
    end
  end

  def edit
    @book = Book.find(params[:id])
  end

  def update
    @book = Book.find(params[:id])
    if @book.update(book_params)
      redirect_to @book, notice: 'Book was successfully updated.'
    else
      render "edit"
    end
  end
  def destroy
    book = Book.find(params[:id])
    book.destroy
    redirect_to books_path
  end

  private
  def book_params
    params.require(:book).permit(:title, :body,)
  end


end
